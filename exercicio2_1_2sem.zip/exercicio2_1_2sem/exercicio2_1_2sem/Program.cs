﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio2_1_2sem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Quadrado a;
            a = new Quadrado(1, 2);

            Console.WriteLine("Lado 1: {0}", a.getL1());
            Console.WriteLine("Lado 2: {0}", a.getL2());

            Console.WriteLine(a.area() ?
                "É triângulo retângulo" :
                "Não é triângulo retângulo");
        }
    }
}
